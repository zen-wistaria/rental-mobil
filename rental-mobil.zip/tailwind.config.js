/** @type {import('tailwindcss').Config} */
module.exports = {
    // content: ["./src/**/**/*.{html,ejs}"],
    content: ["./src/views/**/*.ejs"],
    theme: {
        extend: {},
    },
    plugins: [],
};
