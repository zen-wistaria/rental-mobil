import { app } from "./config/application.js";

app.listen(3000, () => {
    console.log("App listening on port 3000");
});
